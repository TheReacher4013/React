import React from "react";

const Circle = ({ className }) => {
    return <div className={className}></div>;
};

export default Circle;